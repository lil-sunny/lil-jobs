let filters = [];
let selectedFilters = [];

function addFilter(filter) {
  selectedFilters.push(filter);
}

function updateSearch() {
    
}

